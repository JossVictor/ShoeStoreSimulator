
import SwiftUI

@main
struct NikeStoreApp: App {
    var body: some Scene {
        WindowGroup {
            MainContainerView()
        }
    }
}
