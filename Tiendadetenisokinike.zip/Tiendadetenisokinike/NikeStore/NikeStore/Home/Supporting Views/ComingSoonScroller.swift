import SwiftUI

struct ComingSoonScroller: View {
    var body: some View {
        VStack(spacing: 20) {
            ContentHeaderView(title: "PROXIMAMENTE")
            VStack(spacing: 0) {
                ComingSoonView(monthYear: "25 JUNIO'", shortDate: "06/24")
                ComingSoonView(monthYear: "22 JULIO'", shortDate: "07/24")
            }
        }
        .padding(.top, 10)
    }
}

struct ComingSoonScroller_Previews: PreviewProvider {
    static var previews: some View {
        ComingSoonScroller()
    }
}
